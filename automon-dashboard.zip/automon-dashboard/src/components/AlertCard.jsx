import React from 'react';

const AlertCard = ({ alarm }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-4">
      <h2 className="text-xl font-semibold">{alarm.alarmName}</h2>
      <p><strong>Status:</strong> {alarm.state}</p>
      <p><strong>Reason:</strong> {alarm.reason}</p>
      <p><strong>Service:</strong> {alarm.service}</p>
      <p><strong>Time:</strong> {new Date(alarm.time).toLocaleString()}</p>
    </div>
  );
};

export default AlertCard;