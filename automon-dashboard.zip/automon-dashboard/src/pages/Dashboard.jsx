import React, { useEffect, useState } from 'react';
import AlertCard from '../components/AlertCard';

const Dashboard = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    fetch(process.env.REACT_APP_API_URL)
      .then((res) => res.json())
      .then((data) => setAlerts(data))
      .catch((err) => console.error("Failed to load alerts", err));
  }, []);

  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">AutoMon - Cloud Alert Dashboard</h1>
      {alerts.length > 0 ? (
        alerts.map((alarm, i) => <AlertCard key={i} alarm={alarm} />)
      ) : (
        <p>No alerts to display.</p>
      )}
    </div>
  );
};

export default Dashboard;