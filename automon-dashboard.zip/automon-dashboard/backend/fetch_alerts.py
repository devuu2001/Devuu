import json
import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('AutoMonAlerts')

def lambda_handler(event, context):
    try:
        response = table.scan(Limit=50)
        alerts = response.get('Items', [])
        alerts.sort(key=lambda x: x.get('time', 0), reverse=True)

        return {
            "statusCode": 200,
            "headers": { "Access-Control-Allow-Origin": "*" },
            "body": json.dumps(alerts)
        }
    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({ "error": str(e) })
        }